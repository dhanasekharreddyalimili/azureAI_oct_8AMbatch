# # import math as mt

# # from math import tan
# # from math import cos
# # from math import sin

# # print(tan(45))
# # print(cos(90))
# # print(sin(30))

# import fun


# print(fun.myfun())

# print(fun.myfun1())


import random
import datetime
import time

otp=random.randint(000000,999999)

print("OTP generated:",otp)

usrotp=int(input("Please enter the OTP : "))

st=time.time()

if time.time() - st >30:
    print("Entered OTP is expired,please enter the the newly generated OTP")


if usrotp==otp:
    print("enter otp is sucessfull and transation is completed")
else:
    print("Entered OTP is wrong.Please re-enter the OTP:")

