# def myfun():
#     print("This is a function:")


# myfun()

# def myfun(name,city,company):
#     print(name,city,company)

# myfun("ravi",'hyd','msft')

# def myfun(name):
#     return name

# var=myfun("ravi")
# print(var)

# #variable lenth parameter

# def myfun(*name):
#     return name


# var=myfun(2875,"ravi","hyd")
# print("this is info:",var)

# print(type(var))

# #variable-lenth keyword args

# def myfun(*name):
#     print("emp info:",name)
#     print(type(name))





# mylist=[2875,"ravi",39]
# myfun(mylist)



def myfun():
    print("this is a function:")

def myfun1():
    print("Welcome to Azure AI/ML")
