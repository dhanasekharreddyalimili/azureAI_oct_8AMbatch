
try:
    x=int(input("Please enter the Value for X:"))
    y=int(input("Please enter the Values for Y:"))
    z=x/y
    print("Division: ",z)


except ValueError:
    print("input values only integers.Please enter the integer values only")

except ZeroDivisionError:
    print("Any values can not divide by Zero:")
except Exception as ex:
    print("Error occured:",ex)


# x=int(input("Please enter the Value for X:"))
# y=int(input("Please enter the Values for Y:"))
# z=x/y
# print("Division: ",z)


