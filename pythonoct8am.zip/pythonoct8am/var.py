id=2875
name="Ravi"
city="hyd"
sal=99999.99
_emp=True


print(id,type(id))
print(name,type(name))
print(city,type(city))
print(sal,type(sal))
print(sal,type(_emp))
