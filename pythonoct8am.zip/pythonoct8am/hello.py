print("Welcome to python")
print("Welcome to Azure")
print("Welcome to Azure cloud")
print("welcome to Azure github copilot")