from azure.cognitiveservices.vision.computervision import ComputerVisionClient
from msrest.authentication import CognitiveServicesCredentials


subscription_key ="7FAvXlOt2RBnWPB4jqf6i2NyZcaiavxSjFfEv0Q8AQXBNQV4RqhgJQQJ99CJAC8vTInXJ3w3AAAAACOGh4UZ"
endpoint = "https://ai-project1-0680.cognitiveservices.azure.com/"



cv_obj = ComputerVisionClient(endpoint, CognitiveServicesCredentials(subscription_key))





# image_url ="https://upload.wikimedia.org/wikipedia/commons/3/3a/Cat03.jpg?utm_source=chatgpt.com"
image_url="https://learn.microsoft.com/en-us/azure/ai-services/computer-vision/media/quickstarts/presentation.png?utm_source=chatgpt.com"





analysis = cv_obj.analyze_image(image_url, visual_features=["Description", "Tags"])

print(type(analysis))


print("Description: ", analysis.description.captions[0].text)


print("Tags: ", [tag.name for tag in analysis.tags])













import streamlit as st
# from azure.cognitiveservices.vision.computervision import ComputerVisionClient
# from msrest.authentication import CognitiveServicesCredentials

st.write("Hello,Welcome to Azure")

# # Azure Computer Vision Credentials
# subscription_key = "7FAvXlOt2RBnWPB4jqf6i2NyZcaiavxSjFfEv0Q8AQXBNQV4RqhgJQQJ99CJAC8vTInXJ3w3AAAAACOGh4UZ"

# endpoint = "https://ai-project1-0680.cognitiveservices.azure.com/"

# # Initialize Azure Computer Vision Client
# cv_obj = ComputerVisionClient(
#     endpoint,
#     CognitiveServicesCredentials(subscription_key)
# )

# # Streamlit Page Configuration
# st.set_page_config(
#     page_title="Azure Computer Vision",
#     page_icon="👁️",
#     layout="centered"
# )

# st.title("👁️ Azure Computer Vision")
# st.subheader("Image Analysis using Azure AI")

# st.write("Enter an image URL to analyze the image.")

# # Image URL Input
# image_url = st.text_input(
#     "Enter Image URL",
#     value="https://learn.microsoft.com/en-us/azure/ai-services/computer-vision/media/quickstarts/presentation.png"
# )

# # Analyze Button
# if st.button("Analyze Image"):

#     if image_url:

#         try:
#             # Display Image
#             st.image(image_url, caption="Input Image",
#                      use_container_width=True)

#             with st.spinner("Analyzing image using Azure AI..."):

#                 # Analyze Image
#                 analysis = cv_obj.analyze_image(
#                     image_url,
#                     visual_features=["Description", "Tags"]
#                 )

#             st.success("Image Analysis Completed!")

#             # Display Description
#             st.subheader("📝 Image Description")

#             if analysis.description.captions:
#                 caption = analysis.description.captions[0].text
#                 st.write(caption)
#             else:
#                 st.warning("No description available.")

#             # Display Tags
#             st.subheader("🏷️ Image Tags")

#             if analysis.tags:
#                 tags = [tag.name for tag in analysis.tags]
#                 st.write(", ".join(tags))
#             else:
#                 st.warning("No tags available.")

#             # Display Complete Response Type
#             st.subheader("Technical Information")
#             st.write("Response Object Type:", type(analysis).__name__)

#             # Display JSON Response
#             with st.expander("View Complete Azure Response"):
#                 st.json(analysis.as_dict())

#         except Exception as e:
#             st.error(f"Error occurred: {str(e)}")

#     else:
#         st.warning("Please enter a valid image URL.")
