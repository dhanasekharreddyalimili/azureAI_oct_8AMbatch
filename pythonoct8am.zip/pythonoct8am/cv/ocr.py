from azure.ai.vision.imageanalysis import ImageAnalysisClient
from azure.ai.vision.imageanalysis.models import VisualFeatures
from azure.core.credentials import AzureKeyCredential


mykey = "1zS32CRfglONHp4aEwHbaFpGTW7YunztJaASZfdduSDCDngoU0ZVJQQJ99CKAC8vTInXJ3w3AAAAACOGkLNH"
endpoint = "https://ai-project2-5277.cognitiveservices.azure.com/"

client = ImageAnalysisClient(endpoint=endpoint,credential=AzureKeyCredential(mykey))

# Public image URL
image_url = "https://aka.ms/azsdk/image-analysis/sample.jpg"

# OCR
result = client.analyze_from_url(image_url=image_url, visual_features=[VisualFeatures.READ])


if result.read:
    print("___________OCR Text has been generated_______:")
    
    for block in result.read.blocks:
        for line in block.lines:
            print(line.text)
      
        
  