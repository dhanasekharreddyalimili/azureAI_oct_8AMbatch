a=10
b=19

z=a+b
z2=a-b
z3=a*b
z4=a/b
z5=a//b
z6=a**b

print("addition:",z)
print("sub:",z2)
print("mul:",z3)
print("div:",z4)
print("floor div:",z5)
print("exp:",z6)
