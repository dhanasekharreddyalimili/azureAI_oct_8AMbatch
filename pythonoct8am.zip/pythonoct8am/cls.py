class Mycls:
    id=2875
    name="suresh"
    city="hyd"
    age=39

    mycompany="Microsoft"

    def method1(self):
        print("this is a method1",self)
    def method2(self):
        print("This is a method2:",self)

    def __init__(self,name):

       print("This is cons",name)
        
    def dis(self):
        print("id:",self.id)
        print("name:",self.name)
        print("city:",self.city)

    @staticmethod
    def stm1():
        print("This is a static method:")




Mycls.stm1()

print(Mycls.mycompany)

obj=Mycls("python")
obj.dis()
print(obj.id)
print(obj.name)
print(obj.city)
print(obj.age)

obj.method1()
obj.method2()