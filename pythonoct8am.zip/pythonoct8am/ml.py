import requests
url = "https://student-model.eastus2.inference.ml.azure.com/score"
key = "8O0LlK0HH8wwM5WMVg62UScSYuAQQRFpqMNWVjbWl4GBSjlRQjinJQQJ99CJAAAAAAAAAAAAINFRAZML2sOQ"
headers = {"Authorization": f"Bearer {key}","Content-Type": "application/json"}


data = {"StudyHours":3.5}


response = requests.post(url, headers=headers, json=data)
print(response.status_code)

print(response.text)